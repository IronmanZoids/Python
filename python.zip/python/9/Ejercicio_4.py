from functools import reduce
lista=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
acumulador = 0;

def funcion_acumulador(acumulador=0, elemento=0):
    return acumulador + elemento

resultado = reduce(funcion_acumulador, lista)
print(resultado)