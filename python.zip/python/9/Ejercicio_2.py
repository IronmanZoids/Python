lista=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
 
print("Lista original", lista )
 
for i in range(0,len(lista)):
    lista[i]=lista[i]*lista[i]
 
print("El cuadrado de la lista es", lista )