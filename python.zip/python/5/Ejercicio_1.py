  
numero = int(input("Dame un numero: "))

if numero>=1:
    print("El numero que introduciste es positivo ")
else: 
    print("El numero que introduciste es negatvo ")