#Programa que calcule el interés de una cantidad si es mayor al 30%, sino informa el importe total.

