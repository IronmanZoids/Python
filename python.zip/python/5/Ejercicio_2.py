  
numero = int(input("Dame un numero: "))

if numero>=1:
    print("El numero no esta entre el 1 y el 7 ") al 
else: 
    print("Vuelve a intentarlo ")