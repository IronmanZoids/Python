todo=[]
c_1 = input("1er cadena: ")
c_2 = input("2do cadena: ")
c_3 = input("3er cadena: ")
c_4 = input("4er cadena: ")
c_5 = input("5er cadena: ")
todo.append(c_1)
todo.append(c_2)
todo.append(c_3)
todo.append(c_4)
todo.append(c_5)
todo.sort(reverse=True)
print(f"Orden inverso {todo}")
 