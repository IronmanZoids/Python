#ejercicio 3
#a 20 meses

total = 0
all= {}
va=10
for i in range(1, 20): 
    all[i] = va
    all[i+1] = all[i]*2  
    total += va
    va = va*2
print(f" el total por 20 meses pago {total} " )  