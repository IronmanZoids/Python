#numeros primos

def is_primo(num):
    for i in range(2,num):
        if (num%i) == 0:
            return False
    return True

numero = int(input(" Elige el numero para revisar si es primo o no: "))
print(f" el numero {numero} ", "si" if is_primo(numero) else "no", " es numero primo")