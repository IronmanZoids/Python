def solicitar():
  primero = int(input(" Elige el numero: "))
  segundo = int(input(" Elige el otro numero: "))
  return primero, segundo
def sumar( ):
  num1, num2 =  solicitar()
  total = num1 + num2
  print("total es ", total )
def restar():
  num1, num2 =  solicitar()
  total = num1 - num2
  print(f"total de la resta es {total}" )
def multi():
  suma =  solicitar()
  total = suma[0] * suma[1]
  print(f"total de la multiplicacion es {total}" )
def divide():
  suma =  solicitar()
  total = suma[0] / suma[1]
  print(f"total de la division es {total}" )
def menu():
  print("Calculadora")
  print(" 1 suma ")
  print(" 2 RESTAR ")
  print(" 3 MULTI ")
  print(" 4 DIVI ")
  print(" 5 Salir ")
  opcion = int(input(" Elige la opcion: "))
  if opcion==1:
    sumar()
  if opcion==2:
    restar()
  if opcion==3:
    multi()
  if opcion==4:
    divide()
  else:
    exit()

menu()
